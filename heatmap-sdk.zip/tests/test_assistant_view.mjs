import test from "node:test";
import assert from "node:assert/strict";

import {
  confluenceVisualState,
  formatEntryFilter,
  formatPosition,
  signalVisualState,
} from "../static/assistant_view.js";

test("formatEntryFilter shows market and directional filters", () => {
  const text = formatEntryFilter({
    market_state: "READY",
    long_filter: "OK",
    short_filter: "WAIT",
    reason: "buy_exhaustion",
  });

  assert.equal(text, "READY | L:OK S:WAIT | buy_exhaustion");
});

test("formatEntryFilter shows detailed warming progress", () => {
  const text = formatEntryFilter({
    market_state: "WARMING",
    long_filter: "WAIT",
    short_filter: "WAIT",
    reason: "warming 12/50 buckets, 80/200 trades",
  });

  assert.equal(text, "WARMING | L:WAIT S:WAIT | warming 12/50 buckets, 80/200 trades");
});

test("formatEntryFilter handles missing payload", () => {
  assert.equal(formatEntryFilter(null), "entry: -");
});

test("formatPosition shows side quantity pnl and entry", () => {
  const text = formatPosition({
    symbol: "BTCUSDT",
    side: "LONG",
    quantity: 0.012,
    entry_price: 65000,
    unrealized_pnl: 3.5,
  });

  assert.equal(text, "BTCUSDT LONG 0.012 @ 65000 | PnL 3.50");
});

test("formatPosition handles no position", () => {
  assert.equal(formatPosition(null), "position: flat");
});

test("signalVisualState maps long permission to buy", () => {
  assert.deepEqual(
    signalVisualState({ market_state: "READY", long_filter: "OK", short_filter: "WAIT" }),
    { mode: "buy", label: "BUY", reason: "Long conditions" },
  );
});

test("signalVisualState maps short permission to sell", () => {
  assert.deepEqual(
    signalVisualState({ market_state: "READY", long_filter: "WAIT", short_filter: "OK" }),
    { mode: "sell", label: "SELL", reason: "Short conditions" },
  );
});

test("signalVisualState maps toxic to risk", () => {
  assert.deepEqual(
    signalVisualState({ market_state: "TOXIC", reason: "toxic_vpin_watch_only" }),
    { mode: "risk", label: "RISK", reason: "toxic_vpin_watch_only" },
  );
});

test("signalVisualState defaults to wait", () => {
  assert.deepEqual(
    signalVisualState({ market_state: "READY", reason: "no_signal" }),
    { mode: "wait", label: "WAIT", reason: "no_signal" },
  );
});

test("confluenceVisualState highlights matching buy signals", () => {
  assert.deepEqual(
    confluenceVisualState({
      binance: { market_state: "READY", long_filter: "OK", short_filter: "WAIT" },
      bybit: { market_state: "READY", long_filter: "OK", short_filter: "WAIT" },
    }),
    { mode: "buy", label: "BUY x2", reason: "Binance + Bybit" },
  );
});

test("confluenceVisualState waits when exchanges disagree", () => {
  assert.deepEqual(
    confluenceVisualState({
      binance: { market_state: "READY", long_filter: "OK", short_filter: "WAIT" },
      bybit: { market_state: "READY", long_filter: "WAIT", short_filter: "OK" },
    }),
    { mode: "wait", label: "MIXED", reason: "Signals diverge" },
  );
});
