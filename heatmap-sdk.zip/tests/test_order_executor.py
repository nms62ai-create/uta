import pytest

from app.order_executor import OrderExecutor, build_market_close_order
from app.position import PositionState


def test_long_position_closes_with_sell_market_reduce_only():
    pos = PositionState(symbol="BTCUSDT", amount=0.01, entry_price=65000)

    order = build_market_close_order(pos, client_order_id="close-test")

    assert order["symbol"] == "BTCUSDT"
    assert order["side"] == "SELL"
    assert order["type"] == "MARKET"
    assert order["quantity"] == "0.01"
    assert order["reduceOnly"] == "true"
    assert order["newClientOrderId"] == "close-test"


def test_short_position_closes_with_buy_market_reduce_only():
    pos = PositionState(symbol="BTCUSDT", amount=-0.02, entry_price=65000)

    order = build_market_close_order(pos, client_order_id="close-test")

    assert order["side"] == "BUY"
    assert order["quantity"] == "0.02"


def test_flat_position_cannot_build_close_order():
    pos = PositionState(symbol="BTCUSDT", amount=0.0, entry_price=0.0)

    with pytest.raises(ValueError, match="Cannot close a flat position"):
        build_market_close_order(pos, client_order_id="close-test")


class FakeAccountClient:
    def __init__(self):
        self.requests = []

    async def signed_post(self, path, params):
        self.requests.append((path, params))
        return {"status": "FILLED", "clientOrderId": params["newClientOrderId"]}


@pytest.mark.asyncio
async def test_executor_sends_exactly_one_close_request():
    account = FakeAccountClient()
    executor = OrderExecutor(account, client_order_id_factory=lambda: "close-1")
    pos = PositionState(symbol="BTCUSDT", amount=0.01, entry_price=65000)

    result = await executor.close_position(pos)

    assert result["status"] == "FILLED"
    assert len(account.requests) == 1
    assert account.requests[0][0] == "/fapi/v1/order"
    assert account.requests[0][1]["side"] == "SELL"


@pytest.mark.asyncio
async def test_executor_blocks_duplicate_close_while_pending():
    account = FakeAccountClient()
    executor = OrderExecutor(account, client_order_id_factory=lambda: "close-1")
    executor.mark_pending_for_test()
    pos = PositionState(symbol="BTCUSDT", amount=0.01, entry_price=65000)

    with pytest.raises(RuntimeError, match="Close order already pending"):
        await executor.close_position(pos)

    assert account.requests == []
