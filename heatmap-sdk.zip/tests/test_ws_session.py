import pytest

from app.ws_session import BrowserSession, LiveHeatmapService
from app.assistant_config import AssistantRiskSettings
from app.adaptive_service import AdaptiveMarketService
from app.position import PositionState
from app.position_tracker import PositionTracker


def test_start_heatmap_requires_synced_connection():
    session = BrowserSession()

    with pytest.raises(RuntimeError):
        session.start_heatmap()


def test_stop_heatmap_changes_state_to_stopped():
    session = BrowserSession()
    session.mark_synced("BTCUSDT")
    session.start_heatmap()
    session.stop_heatmap()

    assert session.state == "stopped"


@pytest.mark.asyncio
async def test_set_assistant_settings_updates_risk_settings():
    session = BrowserSession()

    event = await session.handle_command(
        {
            "type": "set_assistant_settings",
            "settings": {
                "max_loss_usdt": 2.5,
                "max_holding_time_sec": 12,
                "confirmation_ms": 250,
                "opposite_signal_exit_enabled": False,
                "toxic_vpin_exit_enabled": True,
                "min_price_excursion_bps": 3.5,
                "min_price_excursion_vol_multiplier": 0.8,
            },
        }
    )

    assert event["type"] == "assistant_status"
    assert session.assistant_settings.max_loss_usdt == 2.5
    assert session.assistant_settings.max_holding_time_sec == 12.0
    assert session.assistant_settings.confirmation_ms == 250
    assert session.assistant_settings.opposite_signal_exit_enabled is False
    assert session.assistant_settings.min_price_excursion_bps == 3.5
    assert session.assistant_settings.min_price_excursion_vol_multiplier == 0.8
    assert event["min_price_excursion_bps"] == 3.5
    assert event["min_price_excursion_vol_multiplier"] == 0.8


def test_market_settings_are_applied_to_active_sdk():
    service = LiveHeatmapService()
    service.adaptive_market = AdaptiveMarketService("BTCUSDT")
    service.bybit_adaptive_market = AdaptiveMarketService("BTCUSDT")
    service.session.assistant_settings = AssistantRiskSettings(
        min_price_excursion_bps=4.0,
        min_price_excursion_vol_multiplier=1.2,
    )

    service._apply_assistant_market_settings()

    cfg = service.adaptive_market.symbol_config()
    assert cfg.min_price_excursion_bps == 4.0
    assert cfg.min_price_excursion_vol_multiplier == 1.2
    bybit_cfg = service.bybit_adaptive_market.symbol_config()
    assert bybit_cfg.min_price_excursion_bps == 4.0
    assert bybit_cfg.min_price_excursion_vol_multiplier == 1.2


@pytest.mark.asyncio
async def test_auto_exit_commands_toggle_session_setting():
    session = BrowserSession()

    enabled = await session.handle_command({"type": "enable_auto_exit"})
    disabled = await session.handle_command({"type": "disable_auto_exit"})

    assert enabled["auto_exit_enabled"] is True
    assert disabled["auto_exit_enabled"] is False
    assert session.assistant_settings.auto_exit_enabled is False


@pytest.mark.asyncio
async def test_connect_command_sets_connecting_status():
    session = BrowserSession()

    event = await session.handle_command(
        {"type": "connect", "symbol": "BTCUSDT", "compression": 2}
    )

    assert event["type"] == "status"
    assert event["state"] == "connecting"
    assert event["symbol"] == "BTCUSDT"
    assert event["compression"] == 2
    assert session.compression == 2


@pytest.mark.asyncio
async def test_connect_uses_client_tick_size_and_requested_aggregation(monkeypatch):
    service = LiveHeatmapService()

    class FakeClient:
        def __init__(self, *args, **kwargs):
            self.tick_size = 0.1

        async def start(self):
            return None

        async def stop(self):
            return None

    monkeypatch.setattr("app.ws_session.BinanceMarketClient", FakeClient)
    monkeypatch.setattr("app.ws_session.BybitMarketClient", FakeClient)

    await service._connect_symbol("BTCUSDT", compression=3)

    assert service.frame_builder.tick_size == 0.1
    assert service.frame_builder.aggregation == 3


@pytest.mark.asyncio
async def test_connect_wires_adaptive_market_callbacks(monkeypatch):
    service = LiveHeatmapService()

    class FakeClient:
        def __init__(self, *args, **kwargs):
            self.tick_size = 0.1
            self.on_trade = kwargs.get("on_trade")
            self.on_book_update = kwargs.get("on_book_update")

        async def start(self):
            return None

        async def stop(self):
            return None

    monkeypatch.setattr("app.ws_session.BinanceMarketClient", FakeClient)
    monkeypatch.setattr("app.ws_session.BybitMarketClient", FakeClient)

    await service._connect_symbol("BTCUSDT", compression=1)

    assert service.adaptive_market is not None
    assert service.entry_filter is not None
    assert service.exit_engine is not None
    assert service.client.on_trade is not None
    assert service.client.on_book_update is not None
    assert service.bybit_client is not None
    assert service.bybit_adaptive_market is not None
    assert service.bybit_entry_filter is not None
    assert service.bybit_client.on_trade is not None
    assert service.bybit_client.on_book_update is not None


@pytest.mark.asyncio
async def test_bybit_trade_updates_only_bybit_sdk():
    service = LiveHeatmapService()
    service.adaptive_market = AdaptiveMarketService("BTCUSDT")
    service.bybit_adaptive_market = AdaptiveMarketService("BTCUSDT")

    service._on_bybit_market_trade(
        {
            "symbol": "BTCUSDT",
            "price": 65000.0,
            "qty": 0.1,
            "timestamp": 1700000000000,
            "is_buyer_maker": False,
        }
    )

    assert service.adaptive_market.trade_count == 0
    assert service.bybit_adaptive_market.trade_count == 1


@pytest.mark.asyncio
async def test_refresh_position_updates_tracker():
    service = LiveHeatmapService()
    service.position_tracker = PositionTracker("BTCUSDT")

    class FakeAccount:
        async def fetch_position(self, symbol):
            return PositionState(
                symbol=symbol,
                amount=0.01,
                entry_price=65000,
                unrealized_pnl=1.2,
            )

    service.account_client = FakeAccount()

    position = await service._refresh_position("BTCUSDT", now_ms=1000)

    assert position is not None
    assert position.side == "LONG"
    assert position.opened_at_ms == 1000
    assert service.current_position == position


@pytest.mark.asyncio
async def test_exit_evaluation_closes_position_once_on_hard_exit():
    service = LiveHeatmapService()
    service.session.assistant_settings = AssistantRiskSettings(
        auto_exit_enabled=True,
        max_loss_usdt=5.0,
    )
    service.current_position = PositionState(
        symbol="BTCUSDT",
        amount=0.01,
        entry_price=65000,
        unrealized_pnl=-6.0,
    )

    class FakeExecutor:
        def __init__(self):
            self.calls = []
            self.close_pending = False

        async def close_position(self, position):
            self.calls.append(position)
            self.close_pending = True
            return {"status": "NEW"}

    service.order_executor = FakeExecutor()

    decision = await service._evaluate_exit(now_ms=1000)

    assert decision.should_close is True
    assert decision.reason == "max_loss"
    assert len(service.order_executor.calls) == 1


@pytest.mark.asyncio
async def test_exit_evaluation_broadcasts_exit_and_order_status():
    service = LiveHeatmapService()
    service.session.assistant_settings = AssistantRiskSettings(
        auto_exit_enabled=True,
        max_loss_usdt=5.0,
    )
    service.current_position = PositionState(
        symbol="BTCUSDT",
        amount=0.01,
        entry_price=65000,
        unrealized_pnl=-6.0,
    )
    events = []

    async def capture(payload):
        events.append(payload)

    service.broadcast = capture

    class FakeExecutor:
        close_pending = False

        async def close_position(self, position):
            return {"status": "NEW", "clientOrderId": "abc"}

    service.order_executor = FakeExecutor()

    await service._evaluate_exit(now_ms=1000)

    assert events[0]["type"] == "exit_status"
    assert events[0]["reason"] == "max_loss"
    assert events[1]["type"] == "order_status"
    assert events[1]["status"] == "NEW"
