import hmac
import hashlib
from urllib.parse import parse_qs

import httpx
import pytest

from app.assistant_config import BinanceAccountSettings
from app.binance_account import BinanceAccountClient


def _client(handler):
    transport = httpx.MockTransport(handler)
    settings = BinanceAccountSettings(
        api_key="key",
        api_secret="secret",
        base_url="https://example.test",
    )
    return BinanceAccountClient(settings, transport=transport, now_ms=lambda: 1234567890)


@pytest.mark.asyncio
async def test_start_listen_key_sends_api_key_header():
    seen = {}

    def handler(request: httpx.Request) -> httpx.Response:
        seen["path"] = request.url.path
        seen["api_key"] = request.headers.get("X-MBX-APIKEY")
        return httpx.Response(200, json={"listenKey": "abc"})

    client = _client(handler)

    listen_key = await client.start_listen_key()

    assert listen_key == "abc"
    assert seen["path"] == "/fapi/v1/listenKey"
    assert seen["api_key"] == "key"


@pytest.mark.asyncio
async def test_signed_get_adds_timestamp_and_signature():
    seen = {}

    def handler(request: httpx.Request) -> httpx.Response:
        seen["query"] = request.url.query.decode()
        return httpx.Response(200, json=[])

    client = _client(handler)

    await client.signed_get("/fapi/v3/positionRisk", {"symbol": "BTCUSDT"})

    parsed = parse_qs(seen["query"])
    assert parsed["symbol"] == ["BTCUSDT"]
    assert parsed["timestamp"] == ["1234567890"]
    unsigned = "symbol=BTCUSDT&timestamp=1234567890"
    expected = hmac.new(b"secret", unsigned.encode(), hashlib.sha256).hexdigest()
    assert parsed["signature"] == [expected]


@pytest.mark.asyncio
async def test_fetch_position_normalizes_one_way_position():
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            json=[
                {
                    "symbol": "BTCUSDT",
                    "positionAmt": "0.01",
                    "entryPrice": "65000.0",
                    "breakEvenPrice": "65010.0",
                    "unRealizedProfit": "4.2",
                    "positionSide": "BOTH",
                    "updateTime": 123,
                }
            ],
        )

    client = _client(handler)

    position = await client.fetch_position("BTCUSDT")

    assert position is not None
    assert position.side == "LONG"
    assert position.quantity == 0.01
    assert position.unrealized_pnl == 4.2


@pytest.mark.asyncio
async def test_fetch_position_returns_none_when_symbol_missing():
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json=[])

    client = _client(handler)

    assert await client.fetch_position("BTCUSDT") is None
