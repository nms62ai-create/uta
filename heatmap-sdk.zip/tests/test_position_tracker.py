from app.position import PositionState
from app.position_tracker import PositionTracker


def test_tracker_preserves_open_time_while_position_remains_open():
    tracker = PositionTracker("BTCUSDT")

    first = tracker.update(
        PositionState(symbol="BTCUSDT", amount=0.01, entry_price=65000),
        now_ms=1000,
    )
    second = tracker.update(
        PositionState(symbol="BTCUSDT", amount=0.02, entry_price=65010),
        now_ms=2000,
    )

    assert first.opened_at_ms == 1000
    assert second.opened_at_ms == 1000
    assert second.quantity == 0.02


def test_tracker_resets_when_position_goes_flat():
    tracker = PositionTracker("BTCUSDT")

    tracker.update(PositionState(symbol="BTCUSDT", amount=0.01, entry_price=65000), now_ms=1000)
    flat = tracker.update(PositionState(symbol="BTCUSDT", amount=0.0, entry_price=0.0), now_ms=2000)

    assert flat.side == "FLAT"
    assert flat.opened_at_ms is None
    assert tracker.current is None


def test_tracker_ignores_other_symbols():
    tracker = PositionTracker("BTCUSDT")

    result = tracker.update(
        PositionState(symbol="ETHUSDT", amount=1.0, entry_price=3000),
        now_ms=1000,
    )

    assert result is None
    assert tracker.current is None
