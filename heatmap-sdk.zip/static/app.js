import { createRenderer } from "/static/renderer.js";
import {
  confluenceVisualState,
  formatEntryFilter,
  formatPosition,
  signalVisualState,
} from "/static/assistant_view.js";

const symbolInput = document.getElementById("symbol");
const compressionInput = document.getElementById("compression");
const connectButton = document.getElementById("connect-btn");
const toggleButton = document.getElementById("toggle-btn");
const statusNode = document.getElementById("status");
const displayStepNode = document.getElementById("display-step");
const autoExitInput = document.getElementById("auto-exit");
const maxLossInput = document.getElementById("max-loss");
const maxHoldingInput = document.getElementById("max-holding");
const confirmationInput = document.getElementById("confirmation-ms");
const oppositeExitInput = document.getElementById("opposite-exit");
const toxicExitInput = document.getElementById("toxic-exit");
const assistantStatusNode = document.getElementById("assistant-status");
const entryFilterNode = document.getElementById("entry-filter");
const positionStateNode = document.getElementById("position-state");
const exitStateNode = document.getElementById("exit-state");
const signalCardNode = document.getElementById("signal-card");
const signalLabelNode = document.getElementById("signal-label");
const signalReasonNode = document.getElementById("signal-reason");
const signalDetailNode = document.getElementById("signal-detail");
const buyLightNode = document.getElementById("buy-light");
const waitLightNode = document.getElementById("wait-light");
const sellLightNode = document.getElementById("sell-light");
const minExcursionBpsInput = document.getElementById("min-excursion-bps");
const rvMultiplierInput = document.getElementById("rv-multiplier");
const heatmapCanvas = document.getElementById("heatmap");
const overlayCanvas = document.getElementById("overlay");

const renderer = createRenderer(heatmapCanvas, overlayCanvas);

let socket;
let streaming = false;
const exchangeSignals = {
  binance: null,
  bybit: null,
};

function setStatus(text) {
  statusNode.textContent = text;
}

function setDisplayStep(displayStep, tickSize) {
  if (!displayStep) {
    displayStepNode.textContent = "display step: -";
    return;
  }
  const tickText = tickSize ? ` (tick ${tickSize})` : "";
  displayStepNode.textContent = `display step: ${displayStep}${tickText}`;
}

function setSignalVisual(payload) {
  const exchange = payload?.exchange || "binance";
  exchangeSignals[exchange] = payload;
  const visual = confluenceVisualState(exchangeSignals);
  signalCardNode.className = `signal-card signal-${visual.mode}`;
  signalLabelNode.textContent = visual.label;
  signalReasonNode.textContent = visual.reason;
  signalDetailNode.textContent = [
    `BIN: ${formatEntryFilter(exchangeSignals.binance)}`,
    `BYB: ${formatEntryFilter(exchangeSignals.bybit)}`,
  ].join("\n");

  updateExchangeHalf("binance", signalVisualState(exchangeSignals.binance));
  updateExchangeHalf("bybit", signalVisualState(exchangeSignals.bybit));
}

function updateExchangeHalf(exchange, visual) {
  for (const row of ["buy", "wait", "sell"]) {
    const rowNode = document.querySelector(`[data-signal-row="${row}"]`);
    const halfNode = rowNode?.querySelector(`[data-exchange-half="${exchange}"]`);
    if (!halfNode) {
      continue;
    }
    const isActive = (
      (row === "buy" && visual.mode === "buy") ||
      (row === "sell" && visual.mode === "sell") ||
      (row === "wait" && (visual.mode === "wait" || visual.mode === "risk"))
    );
    halfNode.classList.toggle("active", isActive);
    halfNode.classList.toggle("risk", visual.mode === "risk" && row === "wait");
  }
  buyLightNode.classList.toggle("active", Boolean(buyLightNode.querySelector(".active")));
  waitLightNode.classList.toggle("active", Boolean(waitLightNode.querySelector(".active")));
  sellLightNode.classList.toggle("active", Boolean(sellLightNode.querySelector(".active")));
}

function ensureSocket() {
  if (socket && socket.readyState <= WebSocket.OPEN) {
    return socket;
  }

  const protocol = window.location.protocol === "https:" ? "wss" : "ws";
  socket = new WebSocket(`${protocol}://${window.location.host}/ws`);
  socket.addEventListener("message", (event) => {
    const payload = JSON.parse(event.data);
    if (payload.type === "status") {
      setStatus(payload.state);
      toggleButton.disabled = !["live_ready", "streaming", "stopped"].includes(payload.state);
      if (payload.state === "streaming") {
        streaming = true;
        toggleButton.textContent = "Stop Heatmap";
      } else {
        streaming = false;
        toggleButton.textContent = "Start Heatmap";
      }
    }
    if (payload.type === "frame") {
      renderer.appendColumn(payload.column);
    }
    if (payload.type === "trades") {
      renderer.drawTrades(payload.items || []);
    }
    if (payload.type === "reset") {
      setDisplayStep(payload.display_step, payload.tick_size);
      renderer.reset();
    }
    if (payload.type === "error") {
      setStatus(`error: ${payload.message}`);
    }
    if (payload.type === "assistant_status") {
      autoExitInput.checked = Boolean(payload.auto_exit_enabled);
      maxLossInput.value = payload.max_loss_usdt ?? maxLossInput.value;
      maxHoldingInput.value = payload.max_holding_time_sec ?? maxHoldingInput.value;
      confirmationInput.value = payload.confirmation_ms ?? confirmationInput.value;
      oppositeExitInput.checked = Boolean(payload.opposite_signal_exit_enabled);
      toxicExitInput.checked = Boolean(payload.toxic_vpin_exit_enabled);
      minExcursionBpsInput.value = payload.min_price_excursion_bps ?? minExcursionBpsInput.value;
      rvMultiplierInput.value = (
        payload.min_price_excursion_vol_multiplier ?? rvMultiplierInput.value
      );
      assistantStatusNode.textContent = `assistant: ${payload.auto_exit_enabled ? "AUTO" : "WATCH"}`;
    }
    if (payload.type === "entry_filter") {
      entryFilterNode.textContent = formatEntryFilter(payload);
      setSignalVisual(payload);
    }
    if (payload.type === "position") {
      positionStateNode.textContent = formatPosition(payload);
    }
    if (payload.type === "exit_status") {
      exitStateNode.textContent = `exit: ${payload.state || "-"} ${payload.reason || ""}`;
    }
    if (payload.type === "order_status") {
      exitStateNode.textContent = `order: ${payload.status || "-"}`;
    }
    if (payload.type === "account_error") {
      exitStateNode.textContent = `account: ${payload.message || "error"}`;
    }
  });
  socket.addEventListener("close", () => {
    setStatus("disconnected");
    setDisplayStep(null, null);
    toggleButton.disabled = true;
    streaming = false;
    toggleButton.textContent = "Start Heatmap";
  });
  return socket;
}

function currentAssistantSettings() {
  return {
    max_loss_usdt: Number.parseFloat(maxLossInput.value) || 0,
    max_holding_time_sec: Number.parseFloat(maxHoldingInput.value) || 0,
    confirmation_ms: Number.parseInt(confirmationInput.value, 10) || 0,
    opposite_signal_exit_enabled: oppositeExitInput.checked,
    toxic_vpin_exit_enabled: toxicExitInput.checked,
    min_price_excursion_bps: Number.parseFloat(minExcursionBpsInput.value) || 0,
    min_price_excursion_vol_multiplier: Number.parseFloat(rvMultiplierInput.value) || 0,
  };
}

function sendAssistantSettings() {
  const ws = ensureSocket();
  const send = () => {
    ws.send(
      JSON.stringify({
        type: "set_assistant_settings",
        settings: currentAssistantSettings(),
      }),
    );
  };
  if (ws.readyState === WebSocket.OPEN) {
    send();
  } else {
    ws.addEventListener("open", send, { once: true });
  }
}

connectButton.addEventListener("click", () => {
  const ws = ensureSocket();
  const sendConnect = () => {
    setStatus("connecting");
    ws.send(
      JSON.stringify({
        type: "connect",
        symbol: symbolInput.value.trim().toUpperCase(),
        compression: Math.max(1, Number.parseInt(compressionInput.value, 10) || 1),
      }),
    );
  };
  if (ws.readyState === WebSocket.OPEN) {
    sendConnect();
  } else {
    ws.addEventListener("open", sendConnect, { once: true });
  }
});

toggleButton.addEventListener("click", () => {
  if (!socket || socket.readyState !== WebSocket.OPEN) {
    return;
  }
  if (streaming) {
    socket.send(JSON.stringify({ type: "stop_heatmap" }));
    streaming = false;
    toggleButton.textContent = "Start Heatmap";
    return;
  }
  socket.send(JSON.stringify({ type: "start_heatmap" }));
  streaming = true;
  toggleButton.textContent = "Stop Heatmap";
  setStatus("streaming");
});

autoExitInput.addEventListener("change", () => {
  const ws = ensureSocket();
  const send = () => {
    ws.send(JSON.stringify({ type: autoExitInput.checked ? "enable_auto_exit" : "disable_auto_exit" }));
    sendAssistantSettings();
  };
  if (ws.readyState === WebSocket.OPEN) {
    send();
  } else {
    ws.addEventListener("open", send, { once: true });
  }
});

for (const input of [
  maxLossInput,
  maxHoldingInput,
  confirmationInput,
  oppositeExitInput,
  toxicExitInput,
  minExcursionBpsInput,
  rvMultiplierInput,
]) {
  input.addEventListener("change", sendAssistantSettings);
}

setStatus("disconnected");
