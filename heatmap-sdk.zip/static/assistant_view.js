export function formatEntryFilter(payload) {
  if (!payload) {
    return "entry: -";
  }
  return `${payload.market_state} | L:${payload.long_filter} S:${payload.short_filter} | ${payload.reason}`;
}

export function formatPosition(payload) {
  if (!payload) {
    return "position: flat";
  }
  const pnl = Number(payload.unrealized_pnl || 0).toFixed(2);
  return `${payload.symbol} ${payload.side} ${payload.quantity} @ ${payload.entry_price} | PnL ${pnl}`;
}

export function signalVisualState(payload) {
  if (!payload) {
    return { mode: "wait", label: "WAIT", reason: "No data" };
  }
  if (payload.market_state === "TOXIC" || payload.market_state === "RISKY") {
    return { mode: "risk", label: "RISK", reason: payload.reason || payload.market_state };
  }
  if (payload.long_filter === "OK" && payload.short_filter !== "OK") {
    return { mode: "buy", label: "BUY", reason: "Long conditions" };
  }
  if (payload.short_filter === "OK" && payload.long_filter !== "OK") {
    return { mode: "sell", label: "SELL", reason: "Short conditions" };
  }
  return { mode: "wait", label: "WAIT", reason: payload.reason || "No signal" };
}

export function confluenceVisualState(exchangeStates) {
  const binance = signalVisualState(exchangeStates?.binance);
  const bybit = signalVisualState(exchangeStates?.bybit);
  if (binance.mode === "buy" && bybit.mode === "buy") {
    return { mode: "buy", label: "BUY x2", reason: "Binance + Bybit" };
  }
  if (binance.mode === "sell" && bybit.mode === "sell") {
    return { mode: "sell", label: "SELL x2", reason: "Binance + Bybit" };
  }
  if (binance.mode === "risk" || bybit.mode === "risk") {
    return { mode: "risk", label: "RISK", reason: "One exchange risky" };
  }
  if (binance.mode !== "wait" && bybit.mode !== "wait" && binance.mode !== bybit.mode) {
    return { mode: "wait", label: "MIXED", reason: "Signals diverge" };
  }
  if (binance.mode !== "wait") {
    return { mode: binance.mode, label: binance.label, reason: "Binance only" };
  }
  if (bybit.mode !== "wait") {
    return { mode: bybit.mode, label: bybit.label, reason: "Bybit only" };
  }
  return { mode: "wait", label: "WAIT", reason: "No signal" };
}
