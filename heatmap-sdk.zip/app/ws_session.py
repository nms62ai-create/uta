from __future__ import annotations

import asyncio
import time
from contextlib import suppress
from typing import Any

from fastapi import WebSocket

from app.binance_client import BinanceMarketClient
from app.bybit_client import BybitMarketClient
from app.assistant_config import AssistantRiskSettings, load_default_risk_settings
from app.assistant_config import load_binance_account_settings
from app.adaptive_service import AdaptiveMarketService
from app.binance_account import BinanceAccountClient
from app.entry_filter import AdaptiveVpinRegime, EntryFilterEngine
from app.exit_engine import ExitEngine
from app.order_executor import OrderExecutor
from app.position import PositionState
from app.position_tracker import PositionTracker
from app.frame_builder import FrameBuilder
from app.order_book import OrderBook
from app.settings import (
    FRAME_INTERVAL_MS,
    HEATMAP_BUFFER_LEVELS,
    HEATMAP_HEIGHT,
    HEATMAP_RECENTER_MARGIN_LEVELS,
)
from app.trade_buffer import TradeBuffer


class BrowserSession:
    def __init__(self) -> None:
        self.state = "disconnected"
        self.symbol: str | None = None
        self.compression = 1
        self.assistant_settings = load_default_risk_settings()

    def mark_connecting(self, symbol: str, compression: int = 1) -> None:
        self.symbol = symbol
        self.compression = max(1, int(compression))
        self.state = "connecting"

    def mark_synced(self, symbol: str, compression: int | None = None) -> None:
        self.symbol = symbol
        if compression is not None:
            self.compression = max(1, int(compression))
        self.state = "live_ready"

    def start_heatmap(self) -> None:
        if self.state not in {"live_ready", "stopped", "streaming"}:
            raise RuntimeError("Heatmap requires a synced order book")
        self.state = "streaming"

    def stop_heatmap(self) -> None:
        self.state = "stopped"

    def disconnect(self) -> None:
        self.state = "disconnected"
        self.symbol = None
        self.compression = 1

    async def handle_command(self, command: dict[str, Any]) -> dict[str, Any]:
        command_type = command.get("type")
        if command_type == "connect":
            symbol = str(command.get("symbol", "")).upper()
            compression = int(command.get("compression", 1) or 1)
            self.mark_connecting(symbol, compression=compression)
            return self.status_event()
        if command_type == "start_heatmap":
            self.start_heatmap()
            return self.status_event()
        if command_type == "stop_heatmap":
            self.stop_heatmap()
            return self.status_event()
        if command_type == "disconnect":
            self.disconnect()
            return self.status_event()
        if command_type == "set_assistant_settings":
            self.update_assistant_settings(command.get("settings", {}))
            return self.assistant_status_event()
        if command_type == "enable_auto_exit":
            self.assistant_settings = _replace_settings(
                self.assistant_settings, auto_exit_enabled=True
            )
            return self.assistant_status_event()
        if command_type == "disable_auto_exit":
            self.assistant_settings = _replace_settings(
                self.assistant_settings, auto_exit_enabled=False
            )
            return self.assistant_status_event()
        raise RuntimeError(f"Unsupported command: {command_type}")

    def status_event(self, message: str | None = None) -> dict[str, Any]:
        return {
            "type": "status",
            "state": self.state,
            "symbol": self.symbol,
            "compression": self.compression,
            "message": message,
        }

    def update_assistant_settings(self, payload: dict[str, Any]) -> None:
        current = self.assistant_settings
        self.assistant_settings = AssistantRiskSettings(
            auto_exit_enabled=current.auto_exit_enabled,
            max_loss_usdt=float(payload.get("max_loss_usdt", current.max_loss_usdt)),
            max_holding_time_sec=float(
                payload.get("max_holding_time_sec", current.max_holding_time_sec)
            ),
            confirmation_ms=int(payload.get("confirmation_ms", current.confirmation_ms)),
            opposite_signal_exit_enabled=bool(
                payload.get(
                    "opposite_signal_exit_enabled",
                    current.opposite_signal_exit_enabled,
                )
            ),
            toxic_vpin_exit_enabled=bool(
                payload.get("toxic_vpin_exit_enabled", current.toxic_vpin_exit_enabled)
            ),
            min_price_excursion_bps=max(
                0.0,
                float(
                    payload.get(
                        "min_price_excursion_bps",
                        current.min_price_excursion_bps,
                    )
                ),
            ),
            min_price_excursion_vol_multiplier=max(
                0.0,
                float(
                    payload.get(
                        "min_price_excursion_vol_multiplier",
                        current.min_price_excursion_vol_multiplier,
                    )
                ),
            ),
        )

    def assistant_status_event(self) -> dict[str, Any]:
        settings = self.assistant_settings
        return {
            "type": "assistant_status",
            "auto_exit_enabled": settings.auto_exit_enabled,
            "max_loss_usdt": settings.max_loss_usdt,
            "max_holding_time_sec": settings.max_holding_time_sec,
            "confirmation_ms": settings.confirmation_ms,
            "opposite_signal_exit_enabled": settings.opposite_signal_exit_enabled,
            "toxic_vpin_exit_enabled": settings.toxic_vpin_exit_enabled,
            "min_price_excursion_bps": settings.min_price_excursion_bps,
            "min_price_excursion_vol_multiplier": (
                settings.min_price_excursion_vol_multiplier
            ),
        }


def _replace_settings(
    settings: AssistantRiskSettings,
    **overrides: Any,
) -> AssistantRiskSettings:
    values = {
        "auto_exit_enabled": settings.auto_exit_enabled,
        "max_loss_usdt": settings.max_loss_usdt,
        "max_holding_time_sec": settings.max_holding_time_sec,
        "confirmation_ms": settings.confirmation_ms,
        "opposite_signal_exit_enabled": settings.opposite_signal_exit_enabled,
        "toxic_vpin_exit_enabled": settings.toxic_vpin_exit_enabled,
        "min_price_excursion_bps": settings.min_price_excursion_bps,
        "min_price_excursion_vol_multiplier": (
            settings.min_price_excursion_vol_multiplier
        ),
    }
    values.update(overrides)
    return AssistantRiskSettings(**values)


class LiveHeatmapService:
    def __init__(self) -> None:
        self.session = BrowserSession()
        self.book = OrderBook()
        self.trade_buffer = TradeBuffer()
        self.frame_builder: FrameBuilder | None = None
        self.client: BinanceMarketClient | None = None
        self.adaptive_market: AdaptiveMarketService | None = None
        self.entry_filter: EntryFilterEngine | None = EntryFilterEngine(
            block_on_toxic_vpin=False,
            vpin_regime=AdaptiveVpinRegime(window_ms=60_000),
        )
        self.bybit_book = OrderBook()
        self.bybit_trade_buffer = TradeBuffer()
        self.bybit_client: BybitMarketClient | None = None
        self.bybit_adaptive_market: AdaptiveMarketService | None = None
        self.bybit_entry_filter: EntryFilterEngine | None = EntryFilterEngine(
            block_on_toxic_vpin=False,
            vpin_regime=AdaptiveVpinRegime(window_ms=60_000),
        )
        self.exit_engine: ExitEngine | None = ExitEngine()
        self.account_client: BinanceAccountClient | None = None
        self.order_executor: OrderExecutor | None = None
        self.position_tracker: PositionTracker | None = None
        self.current_position: PositionState | None = None
        self._last_position_poll_ms: int = 0
        self._last_assistant_broadcast_ms: int = 0
        self.frame_task: asyncio.Task | None = None
        self.connections: set[WebSocket] = set()
        self._lock = asyncio.Lock()

    async def register(self, websocket: WebSocket) -> None:
        self.connections.add(websocket)
        await websocket.send_json(self.session.status_event())

    async def unregister(self, websocket: WebSocket) -> None:
        self.connections.discard(websocket)

    async def handle_websocket_command(self, command: dict[str, Any]) -> None:
        event = await self.session.handle_command(command)
        if command.get("type") == "set_assistant_settings":
            self._apply_assistant_market_settings()
        await self.broadcast(event)

        command_type = command["type"]
        if command_type == "connect":
            await self._connect_symbol(
                command["symbol"],
                int(command.get("compression", self.session.compression) or 1),
            )
        elif command_type == "start_heatmap":
            self._ensure_frame_task()
        elif command_type == "stop_heatmap":
            await self._stop_frame_task()
        elif command_type == "disconnect":
            await self._disconnect_market()

    async def _connect_symbol(self, symbol: str, compression: int) -> None:
        async with self._lock:
            await self._stop_frame_task()
            await self._disconnect_market()
            self.book = OrderBook()
            self.trade_buffer = TradeBuffer()
            self.bybit_book = OrderBook()
            self.bybit_trade_buffer = TradeBuffer()
            self.frame_builder = None
            self.adaptive_market = AdaptiveMarketService(symbol)
            self.bybit_adaptive_market = AdaptiveMarketService(symbol)
            self._apply_assistant_market_settings()
            self.entry_filter = EntryFilterEngine(
                block_on_toxic_vpin=False,
                vpin_regime=AdaptiveVpinRegime(window_ms=60_000),
            )
            self.bybit_entry_filter = EntryFilterEngine(
                block_on_toxic_vpin=False,
                vpin_regime=AdaptiveVpinRegime(window_ms=60_000),
            )
            self.exit_engine = ExitEngine()
            self.position_tracker = PositionTracker(symbol)
            account_settings = load_binance_account_settings()
            if account_settings.has_credentials:
                self.account_client = BinanceAccountClient(account_settings)
                self.order_executor = OrderExecutor(self.account_client)
            else:
                self.account_client = None
                self.order_executor = None
            self.client = BinanceMarketClient(
                symbol=symbol,
                order_book=self.book,
                trade_buffer=self.trade_buffer,
                on_trade=self._on_market_trade,
                on_book_update=self._on_book_update,
            )
            self.bybit_client = BybitMarketClient(
                symbol=symbol,
                order_book=self.bybit_book,
                trade_buffer=self.bybit_trade_buffer,
                on_trade=self._on_bybit_market_trade,
                on_book_update=self._on_bybit_book_update,
            )
            try:
                await self.client.start()
                await self.bybit_client.start()
            except Exception as exc:
                self.session.state = "error"
                await self.broadcast({"type": "error", "message": str(exc)})
                await self.broadcast(self.session.status_event(str(exc)))
                await self._disconnect_market()
                return

            self.frame_builder = FrameBuilder(
                height=HEATMAP_HEIGHT,
                tick_size=self.client.tick_size or 0.0,
                aggregation=compression,
                visible_levels=HEATMAP_HEIGHT,
                buffer_levels=HEATMAP_BUFFER_LEVELS,
                recenter_margin_levels=HEATMAP_RECENTER_MARGIN_LEVELS,
            )
            self.session.mark_synced(symbol.upper(), compression=compression)
            await self.broadcast(
                {
                    "type": "reset",
                    "tick_size": self.client.tick_size,
                    "display_step": self.frame_builder.display_step,
                    "buffer_levels": self.frame_builder.buffer_levels,
                }
            )
            await self.broadcast(self.session.status_event())

    def _ensure_frame_task(self) -> None:
        if self.frame_task and not self.frame_task.done():
            return
        self.frame_task = asyncio.create_task(self._frame_loop(), name="heatmap-frame-loop")

    async def _stop_frame_task(self) -> None:
        if self.frame_task is None:
            return
        self.frame_task.cancel()
        with suppress(asyncio.CancelledError):
            await self.frame_task
        self.frame_task = None

    async def _disconnect_market(self) -> None:
        try:
            if self.client is not None:
                await self.client.stop()
        finally:
            self.client = None
            self.adaptive_market = None
            self.entry_filter = None
            if self.bybit_client is not None:
                await self.bybit_client.stop()
            self.bybit_client = None
            self.bybit_adaptive_market = None
            self.bybit_entry_filter = None
            self.exit_engine = None
            self.account_client = None
            self.order_executor = None
            self.position_tracker = None
            self.current_position = None
            self._last_position_poll_ms = 0
            self._last_assistant_broadcast_ms = 0
            self.session.disconnect()

    def _on_market_trade(self, trade: dict[str, Any]) -> None:
        if self.adaptive_market is None:
            return
        self.adaptive_market.on_agg_trade(trade)
        self._schedule_assistant_snapshot()

    def _on_bybit_market_trade(self, trade: dict[str, Any]) -> None:
        if self.bybit_adaptive_market is None:
            return
        self.bybit_adaptive_market.on_agg_trade(trade)
        self._schedule_assistant_snapshot()

    def _on_book_update(self, book: OrderBook, event_time_ms: int | None) -> None:
        if self.adaptive_market is None:
            return
        best_bid = book.best_bid()
        best_ask = book.best_ask()
        if best_bid is None or best_ask is None:
            return
        bid_vol = book.bids.get(best_bid, 0.0)
        ask_vol = book.asks.get(best_ask, 0.0)
        self.adaptive_market.on_top_of_book(
            best_bid=best_bid,
            best_ask=best_ask,
            bid_vol=bid_vol,
            ask_vol=ask_vol,
            timestamp_ms=event_time_ms,
        )
        self._schedule_assistant_snapshot()

    def _on_bybit_book_update(self, book: OrderBook, event_time_ms: int | None) -> None:
        if self.bybit_adaptive_market is None:
            return
        best_bid = book.best_bid()
        best_ask = book.best_ask()
        if best_bid is None or best_ask is None:
            return
        bid_vol = book.bids.get(best_bid, 0.0)
        ask_vol = book.asks.get(best_ask, 0.0)
        self.bybit_adaptive_market.on_top_of_book(
            best_bid=best_bid,
            best_ask=best_ask,
            bid_vol=bid_vol,
            ask_vol=ask_vol,
            timestamp_ms=event_time_ms,
        )
        self._schedule_assistant_snapshot()

    def _schedule_assistant_snapshot(self) -> None:
        now_ms = int(time.time() * 1000)
        if now_ms - self._last_assistant_broadcast_ms < 500:
            return
        self._last_assistant_broadcast_ms = now_ms
        asyncio.create_task(self._broadcast_assistant_snapshot())

    def _apply_assistant_market_settings(self) -> None:
        if self.adaptive_market is None:
            pass
        else:
            settings = self.session.assistant_settings
            self.adaptive_market.update_price_excursion_settings(
                min_price_excursion_bps=settings.min_price_excursion_bps,
                min_price_excursion_vol_multiplier=(
                    settings.min_price_excursion_vol_multiplier
                ),
            )
        if self.bybit_adaptive_market is None:
            return
        settings = self.session.assistant_settings
        self.bybit_adaptive_market.update_price_excursion_settings(
            min_price_excursion_bps=settings.min_price_excursion_bps,
            min_price_excursion_vol_multiplier=(
                settings.min_price_excursion_vol_multiplier
            ),
        )

    async def _frame_loop(self) -> None:
        interval_seconds = FRAME_INTERVAL_MS / 1000
        try:
            while self.session.state == "streaming":
                if self.frame_builder is None:
                    await asyncio.sleep(interval_seconds)
                    continue
                frame = self.frame_builder.build(self.book, self.trade_buffer.drain())
                await self.broadcast(
                    {
                        "type": "frame",
                        "timestamp": frame.timestamp,
                        "column": frame.column,
                        "mid_price": frame.mid_price,
                        "best_bid": frame.best_bid,
                        "best_ask": frame.best_ask,
                    }
                )
                await self.broadcast(
                    {
                        "type": "trades",
                        "timestamp": time.time_ns(),
                        "items": [
                            {
                                "price": trade.price,
                                "qty": trade.qty,
                                "y": trade.y,
                                "is_buyer_maker": trade.is_buyer_maker,
                            }
                            for trade in frame.trades
                        ],
                    }
                )
                now_ms = int(time.time() * 1000)
                await self._poll_position_if_due(now_ms)
                await self._evaluate_exit(now_ms)
                await self._broadcast_assistant_snapshot()
                await asyncio.sleep(interval_seconds)
        except asyncio.CancelledError:
            raise

    async def _poll_position_if_due(self, now_ms: int) -> None:
        symbol = self.session.symbol
        if symbol is None or self.account_client is None:
            return
        if now_ms - self._last_position_poll_ms < 1000:
            return
        self._last_position_poll_ms = now_ms
        await self._refresh_position(symbol, now_ms)

    async def _refresh_position(
        self,
        symbol: str,
        now_ms: int,
    ) -> PositionState | None:
        if self.account_client is None or self.position_tracker is None:
            return None
        position = await self.account_client.fetch_position(symbol)
        tracked = self.position_tracker.update(position, now_ms)
        self.current_position = tracked if tracked is not None and tracked.is_open else None
        return tracked

    async def _evaluate_exit(self, now_ms: int):
        if self.exit_engine is None or self.current_position is None:
            return None
        decision = self.exit_engine.evaluate(
            position=self.current_position,
            sdk_state=self.adaptive_market.state() if self.adaptive_market is not None else None,
            latest_signal=(
                self.adaptive_market.latest_signal if self.adaptive_market is not None else None
            ),
            settings=self.session.assistant_settings,
            now_ms=now_ms,
        )
        if decision.reason is not None:
            await self.broadcast(
                {
                    "type": "exit_status",
                    "state": decision.state,
                    "reason": decision.reason,
                    "should_close": decision.should_close,
                    "hard_exit": decision.hard_exit,
                }
            )
        if (
            decision.should_close
            and self.order_executor is not None
            and not self.order_executor.close_pending
        ):
            try:
                order_result = await self.order_executor.close_position(self.current_position)
            except Exception as exc:
                await self.broadcast({"type": "account_error", "message": str(exc)})
            else:
                await self.broadcast(
                    {
                        "type": "order_status",
                        "status": order_result.get("status"),
                        "clientOrderId": order_result.get("clientOrderId"),
                    }
                )
        return decision

    async def _broadcast_assistant_snapshot(self) -> None:
        await self.broadcast(self.session.assistant_status_event())
        if self.adaptive_market is not None and self.entry_filter is not None:
            now_ms = int(time.time() * 1000)
            warmup = self.adaptive_market.warmup_progress()
            result = self.entry_filter.evaluate(
                self.adaptive_market.state(),
                self.adaptive_market.latest_signal_for_display(now_ms),
                trade_count=warmup["trade_count"],
                min_buckets_for_vpin=warmup["min_buckets_for_vpin"],
                min_ticks_for_z=warmup["min_ticks_for_z"],
                now_ms=now_ms,
            )
            await self.broadcast(
                {
                    "type": "entry_filter",
                    "market_state": result.market_state,
                    "long_filter": result.long_filter,
                    "short_filter": result.short_filter,
                    "reason": result.reason,
                    "latest_signal_type": result.latest_signal_type,
                    "latest_signal_confidence": result.latest_signal_confidence,
                    "vpin": result.vpin,
                    "exchange": "binance",
                }
            )
        if self.bybit_adaptive_market is not None and self.bybit_entry_filter is not None:
            now_ms = int(time.time() * 1000)
            warmup = self.bybit_adaptive_market.warmup_progress()
            result = self.bybit_entry_filter.evaluate(
                self.bybit_adaptive_market.state(),
                self.bybit_adaptive_market.latest_signal_for_display(now_ms),
                trade_count=warmup["trade_count"],
                min_buckets_for_vpin=warmup["min_buckets_for_vpin"],
                min_ticks_for_z=warmup["min_ticks_for_z"],
                now_ms=now_ms,
            )
            await self.broadcast(
                {
                    "type": "entry_filter",
                    "exchange": "bybit",
                    "market_state": result.market_state,
                    "long_filter": result.long_filter,
                    "short_filter": result.short_filter,
                    "reason": result.reason,
                    "latest_signal_type": result.latest_signal_type,
                    "latest_signal_confidence": result.latest_signal_confidence,
                    "vpin": result.vpin,
                }
            )
        if self.current_position is not None:
            await self.broadcast(
                {
                    "type": "position",
                    "symbol": self.current_position.symbol,
                    "side": self.current_position.side,
                    "quantity": self.current_position.quantity,
                    "entry_price": self.current_position.entry_price,
                    "unrealized_pnl": self.current_position.unrealized_pnl,
                    "opened_at_ms": self.current_position.opened_at_ms,
                }
            )

    async def broadcast(self, payload: dict[str, Any]) -> None:
        stale_connections: list[WebSocket] = []
        for websocket in self.connections:
            try:
                await websocket.send_json(payload)
            except Exception:
                stale_connections.append(websocket)
        for websocket in stale_connections:
            self.connections.discard(websocket)
