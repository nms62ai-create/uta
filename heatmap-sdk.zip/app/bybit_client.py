from __future__ import annotations

import asyncio
import json
from collections.abc import Callable
from contextlib import suppress
from typing import Any

import websockets
from websockets.exceptions import ConnectionClosed, ConnectionClosedError, ConnectionClosedOK

from app.order_book import OrderBook
from app.settings import BYBIT_LINEAR_PUBLIC_WS_URL
from app.trade_buffer import TradeBuffer


class BybitMarketClient:
    def __init__(
        self,
        symbol: str,
        order_book: OrderBook,
        trade_buffer: TradeBuffer,
        *,
        on_trade: Callable[[dict[str, Any]], None] | None = None,
        on_book_update: Callable[[OrderBook, int | None], None] | None = None,
        depth: int = 50,
    ) -> None:
        self.symbol = symbol.upper()
        self.order_book = order_book
        self.trade_buffer = trade_buffer
        self.on_trade = on_trade
        self.on_book_update = on_book_update
        self.depth = int(depth)
        self.tick_size: float | None = None
        self._stream_task: asyncio.Task | None = None
        self._synced = asyncio.Event()

    async def start(self) -> None:
        self._stream_task = asyncio.create_task(self._run(), name=f"bybit:{self.symbol}")

    async def stop(self) -> None:
        if self._stream_task is None:
            return
        self._stream_task.cancel()
        with suppress(
            asyncio.CancelledError,
            TimeoutError,
            ConnectionClosed,
            ConnectionClosedError,
            ConnectionClosedOK,
        ):
            await self._stream_task
        self._stream_task = None
        self._synced.clear()

    async def _run(self) -> None:
        async with websockets.connect(
            BYBIT_LINEAR_PUBLIC_WS_URL,
            ping_interval=20,
            ping_timeout=20,
        ) as ws:
            await ws.send(json.dumps(self._build_subscribe_message(self.symbol, self.depth)))
            async for message in ws:
                self._process_stream_event(json.loads(message))

    @staticmethod
    def _build_subscribe_message(symbol: str, depth: int = 50) -> dict[str, Any]:
        normalized_symbol = symbol.upper()
        return {
            "op": "subscribe",
            "args": [
                f"orderbook.{int(depth)}.{normalized_symbol}",
                f"publicTrade.{normalized_symbol}",
            ],
        }

    def _process_stream_event(self, event: dict[str, Any]) -> None:
        topic = str(event.get("topic", ""))
        if topic.startswith("orderbook."):
            self._process_orderbook_event(event)
        elif topic.startswith("publicTrade."):
            self._process_public_trade_event(event)

    def _process_orderbook_event(self, event: dict[str, Any]) -> None:
        data = event.get("data") or {}
        bids = data.get("b", [])
        asks = data.get("a", [])
        if event.get("type") == "snapshot":
            self.order_book.load_snapshot(bids, asks)
            self._synced.set()
        else:
            self.order_book.apply_delta(bids, asks)
        if self.on_book_update is not None:
            self.on_book_update(self.order_book, event.get("ts") or data.get("cts"))

    def _process_public_trade_event(self, event: dict[str, Any]) -> None:
        for item in event.get("data") or []:
            side = str(item.get("S", ""))
            trade = {
                "symbol": str(item.get("s", self.symbol)).upper(),
                "price": float(item["p"]),
                "qty": float(item["v"]),
                "timestamp": int(item["T"]),
                "is_buyer_maker": side == "Sell",
            }
            self.trade_buffer.add(trade)
            if self.on_trade is not None:
                self.on_trade(trade)
