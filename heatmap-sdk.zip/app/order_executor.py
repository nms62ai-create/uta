from __future__ import annotations

from collections.abc import Callable
from decimal import Decimal
from uuid import uuid4

from app.position import PositionState


def build_market_close_order(
    position: PositionState,
    *,
    client_order_id: str,
) -> dict[str, str]:
    if not position.is_open:
        raise ValueError("Cannot close a flat position")
    side = "SELL" if position.amount > 0 else "BUY"
    return {
        "symbol": position.symbol,
        "side": side,
        "type": "MARKET",
        "quantity": _format_quantity(position.quantity),
        "reduceOnly": "true",
        "newClientOrderId": client_order_id,
    }


class OrderExecutor:
    """Single-purpose executor for market-closing the current position."""

    def __init__(
        self,
        account_client,
        *,
        client_order_id_factory: Callable[[], str] | None = None,
    ) -> None:
        self._account_client = account_client
        self._client_order_id_factory = client_order_id_factory or _default_client_order_id
        self._close_pending = False

    async def close_position(self, position: PositionState) -> dict:
        if self._close_pending:
            raise RuntimeError("Close order already pending")
        client_order_id = self._client_order_id_factory()
        params = build_market_close_order(position, client_order_id=client_order_id)
        self._close_pending = True
        try:
            result = await self._account_client.signed_post("/fapi/v1/order", params)
            return result
        except Exception:
            self._close_pending = False
            raise

    def mark_close_confirmed(self) -> None:
        self._close_pending = False

    def mark_pending_for_test(self) -> None:
        self._close_pending = True

    @property
    def close_pending(self) -> bool:
        return self._close_pending


def _format_quantity(quantity: float) -> str:
    text = format(Decimal(str(quantity)).normalize(), "f")
    if "." in text:
        text = text.rstrip("0").rstrip(".")
    return text or "0"


def _default_client_order_id() -> str:
    return f"hm-sdk-close-{uuid4().hex[:20]}"
