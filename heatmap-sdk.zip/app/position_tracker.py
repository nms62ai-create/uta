from __future__ import annotations

from dataclasses import replace

from app.position import PositionState


class PositionTracker:
    def __init__(self, symbol: str) -> None:
        self.symbol = symbol.upper()
        self.current: PositionState | None = None

    def update(self, position: PositionState | None, now_ms: int) -> PositionState | None:
        if position is None:
            self.current = None
            return None
        if position.symbol != self.symbol:
            return self.current
        if not position.is_open:
            flat = replace(position, opened_at_ms=None)
            self.current = None
            return flat

        opened_at_ms = self.current.opened_at_ms if self.current is not None else None
        if opened_at_ms is None:
            opened_at_ms = now_ms
        current = replace(position, opened_at_ms=opened_at_ms)
        self.current = current
        return current
